package fp.daw.examen2ev;

public interface PrecioAlquiler {
	
	public void getPrecioAlquiler(int dias);
}
